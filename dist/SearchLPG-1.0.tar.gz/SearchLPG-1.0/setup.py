from distutils.core import setup, Extension
setup(name='SearchLPG',
version='1.0',
classifiers = [ 'Search LPG OilStation'],
packages=['Search LPG OilStation'],
)
